cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/com-moduscreate-plugins-echo/www/ModusEcho.js",
        "id": "com-moduscreate-plugins-echo.ModusEcho",
        "pluginId": "com-moduscreate-plugins-echo",
        "clobbers": [
            "modusecho"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.3.2",
    "com-moduscreate-plugins-echo": "0.0.1"
}
// BOTTOM OF METADATA
});